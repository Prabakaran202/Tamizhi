; ModuleID = 'tamizhi_engine'
source_filename = "tamizhi_engine"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android30"

@resp_str = private unnamed_addr constant [54 x i8] c"<h1>Vanakkam Praba! Tamizhi Server is 100% Live!</h1>\00", align 4

; Function Attrs: noreturn
define noundef i32 @main() local_unnamed_addr #0 {
entry:
  tail call void @tamizhi_rt_listen(i32 8080)
  br label %while_cond_0

while_cond_0:                                     ; preds = %while_cond_0, %entry
  %client_socket = tail call i32 @tamizhi_rt_accept()
  tail call void @tamizhi_rt_send_response(i32 %client_socket, i32 200, ptr nonnull @resp_str)
  br label %while_cond_0
}

declare void @tamizhi_rt_listen(i32) local_unnamed_addr

declare i32 @tamizhi_rt_accept() local_unnamed_addr

declare void @tamizhi_rt_send_response(i32, i32, ptr) local_unnamed_addr

attributes #0 = { noreturn }
